package com.lau.guesstheapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Hard_mode extends AppCompatActivity {

    public ArrayList <String> WebImage;
    public ArrayList <String> ImageName;
    public ArrayList <Bitmap> pic;
    public int counter=10;
    ImageView imgView;
    TextView textView;
    Button b1;
    Button b2;
    Button b3;
    Button b4;
    int questionNumb = 0;
    int score = 0;
    TextView scoreText;
    String correctAnswer = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hard_mode);

        imgView=(ImageView) findViewById(R.id.imageView);

        textView= (TextView) findViewById(R.id.textView);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);

        ImageName = new ArrayList<String>();
        WebImage = new ArrayList<String>();
        pic = new ArrayList<Bitmap>();

        WebsiteExtractor we = new WebsiteExtractor();

        ImageDownloader ID=new ImageDownloader();


        try{
            we.execute("https://www.pcmag.com/picks/best-android-apps").get();
            for(int i=0;i<WebImage.size();i++){
                Log.i("url", WebImage.get(i));
                WebImage.remove("https://i.pcmag.com/imagery/authors/02TCRPjyAMa38Y9ch8XjF9L.1560221534.fit_lim.size_100x100.jpg");
                WebImage.remove("https://i.pcmag.com/imagery/authors/02zeO33Kq1h1VFOMsjsYJFV.1588602007.fit_lim.size_100x100.jpg");
                WebImage.remove("https://i.pcmag.com/imagery/collections/05paiTHjPKdcsppfxB4lpUY-3.1608132415.fit_lim.size_1028x578.jpg");
                WebImage.remove("https://i.pcmag.com/imagery/collections/05paiTHjPKdcsppfxB4lpUY-3.1608132415.fit_lim.size_400x225.jpg");
                WebImage.remove("https://seal-newyork.bbb.org/seals/blue-seal-96-50-bbb-531.png");
                WebImage.remove("https://c.evidon.com/pub/icong1.png");
                WebImage.remove("https://i.pcmag.com/imagery/reviews/06fdvkyOgcsc4kzcSqhLmxB-12.1601663115.fit_lpad.size_400x225.png");
                WebImage.remove("https://i.pcmag.com/imagery/reviews/05APdsOCiIycSMx6qrrOGR5-1.1602881834.fit_lpad.size_400x225.png");
                WebImage.remove("https://i.pcmag.com/imagery/articles/03Q5WATfsiViMb89k9senbW-21.1634928420.fit_lpad.size_400x225.jpg");
                WebImage.remove("https://i.pcmag.com/imagery/articles/06rhTHszEXqjMaKPHxYCina-12.1615909011.fit_lpad.size_400x225.jpg");
                WebImage.remove("https://i.pcmag.com/imagery/collections/05paiTHjPKdcsppfxB4lpUY-3.1608132415.fit_lim.size_760x427.jpg");
                WebImage.remove("https://i.pcmag.com/imagery/collections/05paiTHjPKdcsppfxB4lpUY-3.1608132415.fit_lim.size_1200x630.jpg");
            }
            ID.execute(WebImage.toArray(new String[0])).get();

        }
        catch (Exception e) {
            e.printStackTrace();
        }






         StartGame();



        new CountDownTimer(30000, 1000){
            public void onTick(long millisUntilFinished){
                textView.setText(String.valueOf(counter));
                if(counter>0){
                    counter--;
                }
                else{
                    Toast.makeText(getApplicationContext(), "Time is Up!", Toast.LENGTH_SHORT).show();
                }

            }
            public  void onFinish(){
                textView.setText("TIME'S UP!");
            }
        }.start();




            }


    public class ImageDownloader extends AsyncTask<String,Void, Bitmap>{

        protected Bitmap doInBackground(String... urls) {
            URL url;
            try {

                for(int i=0;i<WebImage.size();i++ ) {


                    url = new URL(urls[i]);

                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.connect();

                    InputStream in = connection.getInputStream();
                    Bitmap downloadedImage = BitmapFactory.decodeStream(in);

                    pic.add(downloadedImage);


                }
                return null;

            }
            catch (Exception e) {
                e.printStackTrace();
                return  null;
            }
        }
            }

    public class WebsiteExtractor extends AsyncTask<String,Void, String>{


        protected String doInBackground(String... urls) {

            StringBuilder stringBuilder = new StringBuilder();
            try {
                URL url= new URL(urls[0]);

                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));

                String input;

                while((input = bufferedReader.readLine()) != null)
                {
                    stringBuilder.append(input);

                }
                Pattern p=Pattern.compile("http(s?)://([\\w-]+\\.)+[\\w-]+(/[\\w- ./]*)+\\.(?:[jJ][pP][gG]|[pP][nN][gG])");
                Matcher m =p.matcher(stringBuilder.toString());

                while (m.find()){

                    String f = m.group();
                    WebImage.add(f);

                }

                p=Pattern.compile("<h2 class=\"order-last md:order-first font-bold font-brand text-lg md:text-xl leading-normal w-full\">(.*?)</h2>");
                m =p.matcher(stringBuilder.toString());

                while (m.find()){
                    String s = m.group();
                    s=s.substring(s.indexOf(">")+1,s.indexOf("</h2>"));
                    ImageName.add(s);
                }

                return stringBuilder.toString();

            } catch (Exception e) {
                e.printStackTrace();
                return "failed";
            }
        }
    }




    public void StartGame() {



            ArrayList c = new ArrayList<String>();


            String o1 = "";
            String o2 = "";
            String o3 = "";
            String o4 = "";
            Random rand = new Random();
            int random = rand.nextInt(ImageName.size());
            imgView.setImageBitmap(pic.get(random));

            correctAnswer = ImageName.get(random);
            c.add(correctAnswer);

            while (c.size() < 4) {
                int random2 = rand.nextInt(ImageName.size());
                if (!correctAnswer.equalsIgnoreCase(ImageName.get(random2)))
                    c.add(ImageName.get(random2));
            }

            int j = rand.nextInt(c.size());
            o1 = c.get(j).toString();
            c.remove(j);
            b1.setText(o1);
            j = rand.nextInt(c.size());
            o2 = c.get(j).toString();
            c.remove(j);
            b2.setText(o2);
            j = rand.nextInt(c.size());
            o3 = c.get(j).toString();
            c.remove(j);
            b3.setText(o3);
            j = rand.nextInt(c.size());
            b4.setText(c.get(j).toString());
            c.remove(j);    

    }

    public void onClickAnswerButton(View view){
        Button button = (Button) view;
        scoreText.setText(Integer.toString(score));
        if(button.getText().toString().equals(correctAnswer)){
//            Toast.makeText(this, "Correct", Toast.LENGTH_SHORT).show();
            score+=2;
            StartGame();

        }
        else {
            score--;
            StartGame();
        }


    }
    }








