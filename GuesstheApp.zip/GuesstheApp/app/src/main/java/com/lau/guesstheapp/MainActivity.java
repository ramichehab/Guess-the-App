 package com.lau.guesstheapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;

import android.content.Intent;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

 public class MainActivity extends AppCompatActivity {
     private Button ebutton;
     private Button mbutton;
     private Button hbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ebutton = (Button)findViewById(R.id.easy);

        mbutton = (Button)findViewById(R.id.medium);
        hbutton = (Button)findViewById(R.id.hard);

        ebutton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                openEasy();
            }
        });

        mbutton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                openMedium();
            }
        });



        hbutton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                openHard();
            }
        });
    }



     public void openEasy()
     {
         Intent intent = new Intent(this,Easy_mode.class);
         startActivity(intent);
     }



     public void openMedium()
     {
         Intent intent = new Intent(this,Medium_mode.class);
         startActivity(intent);
     }


     public void openHard()
     {
         Intent intent = new Intent(this,Hard_mode.class);
         startActivity(intent);
     }






}